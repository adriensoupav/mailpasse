package com.example.flutteremailpasse

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
